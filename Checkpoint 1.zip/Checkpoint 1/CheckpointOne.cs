using System;

namespace Checkpoint_1
{

    class CheckPointClassOne


    {

        public void divisbleBYThree()
        {
            for( int i = 1; i <= 100; i++)
            {
                if(i % 3 == 0)
                {
                    Console.WriteLine(i);

                }

            }

        }

        public void sumOfAll()
        {
            int sum = 0;
            string exit = "ok";
            bool willContinue = true;
            string response = "";

            do
            {
                Console.WriteLine("Please enter a number.");
                sum = sum + int.Parse(Console.ReadLine());
                Console.WriteLine("Your sum is : {0} ", sum);
                Console.WriteLine("Type \"ok\" to exit; or press Enter to continue.");
                response = Console.ReadLine();
                response.ToLower();
                    if(response == exit )
                    {
                        willContinue = false;

                    }

            }

            while(willContinue);

        }





    }







}